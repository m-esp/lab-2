Rails.application.routes.draw do
  resources :posts do
    resources :comments, only: [:create, :destroy]
    resources :likes, only: [:create, :destroy]
  end
  resources :users, only: [:show, :edit, :update]
  get '/hashtag/:name', to: 'hashtags#show', as: :hashtag
  get 'about', to: 'pages#about', as: 'about'
  get 'contact', to: 'pages#contact', as: 'contact'
  get 'profile/edit', to: 'profiles#edit', as: 'edit_profile'


  root 'posts#index'
end
