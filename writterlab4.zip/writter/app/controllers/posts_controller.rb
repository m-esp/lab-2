class PostsController < ApplicationController
  before_action :set_post, only: [:show, :edit, :update, :destroy]

  def index
    @posts = Post.all
  end

  def show
  end

  def new
    @post = Post.new
  end

  def create
    @post = Post.new(post_params)
    @post.author = params[:author]

    if @post.save
      hashtags = process_hashtags(params[:post][:hashtags])
      handle_hashtags(@post, hashtags)
      redirect_to @post, notice: 'Post was successfully created.'
    else
      render :new
    end
  end

  def edit
  end

  def update
    if @post.update(post_params)
      hashtags = process_hashtags(params[:post][:hashtags])
      handle_hashtags(@post, hashtags)
      redirect_to @post, notice: 'Post was successfully updated.'
    else
      render :edit
    end
  end

  def destroy
    @post.destroy
    redirect_to posts_path, notice: 'Post was successfully deleted.'
  end

  private

  def set_post
    @post = Post.find(params[:id])
  end

  def post_params
    params.require(:post).permit(:content, :title, :author, images: []) 
  end

  def process_hashtags(hashtags)
    hashtags.to_s.split(',').map(&:strip)
  end

  def handle_hashtags(post, hashtags)
    post.hashtags.destroy_all 
    hashtags.each do |hashtag|
      post.hashtags.create(name: hashtag)
    end
  end
end
