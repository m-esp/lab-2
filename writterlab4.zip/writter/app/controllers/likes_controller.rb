class LikesController < ApplicationController
  before_action :set_post

  def create
    user_email = params[:user_email] 

    if @post.likes.where(author: user_email).exists?
      flash[:notice] = "You've already liked this post."
    else
      @post.likes.create(author: user_email) 
    end
    redirect_to @post
  end

  def destroy
    like = @post.likes.find(params[:id])
    user_email = params[:user_email]

    if like.author == user_email 
      like.destroy
    end
    redirect_to @post
  end

  private

  def set_post
    @post = Post.find(params[:post_id])
  end
end
