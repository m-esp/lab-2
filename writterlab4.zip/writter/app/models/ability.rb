class Ability
  include CanCan::Ability

  def initialize(user)
    user ||= User.new # guest user (not logged in)
    
    can :read, :all # everyone can read everything

    if user.persisted?
      can :manage, Post, user_id: user.id
      can :manage, Comment, user_id: user.id
    end
  end
end
