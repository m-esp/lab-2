class Comment < ApplicationRecord
  validates :content, presence: true
  validates :author, presence: true, format: { with: URI::MailTo::EMAIL_REGEXP, message: "must be a valid email" }
end
