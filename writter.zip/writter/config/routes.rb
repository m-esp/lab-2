Rails.application.routes.draw do
  get "pages/home"
  get "pages/about"
  get "pages/contact"
  root 'pages#home'
  get 'about', to: 'pages#about'
  get 'contact', to: 'pages#contact'
end
